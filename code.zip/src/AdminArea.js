import React from "react";

const AdminArea = () =>{
    return(
        <h2>Admin Area (This is a protected page)</h2>
    )
}

export default AdminArea;